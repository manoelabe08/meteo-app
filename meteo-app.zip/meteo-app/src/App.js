import React from 'react';

function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>🌤️ Application Météo</h1>
      <p>Bienvenue sur mon appli météo !</p>
    </div>
  );
}

export default App;
